#include <stdio.h>
#include "HW_01.h"
int calculate(int s,int y,int z);
int
main ()
{
	int a, b, c,v;
	int X;

	a = 10;
	b = 20;
	c = 30;
	v = a+c;
	X = calculate(a, b, c);

	printf("X = %d\n", X);
	return 0;
}
