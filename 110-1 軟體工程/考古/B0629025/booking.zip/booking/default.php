<?php session_start(); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<link rel="stylesheet" href="css/bootstrap.min.css" >
<link rel="stylesheet" href="style.css" >

 <link rel="stylesheet" href="js/jquery-ui.css">
  <script src="js/jquery-1.12.4.js"></script>
  <script src="js/jquery-ui.js"></script>

<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script>
$( function() {
    $( ".datepicker" ).datepicker({
      dateFormat: 'yy/mm/dd'
    });
});
</script>
