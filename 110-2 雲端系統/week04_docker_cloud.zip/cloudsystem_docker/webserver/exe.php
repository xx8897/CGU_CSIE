<?php

ini_set('display_errors','1');
error_reporting(E_ALL);


$dirname = time().".".rand(0,100);
$dirPath = "/share/".$dirname."/";

$cmd = "mkdir $dirPath;chmod -Rf 777 $dirPath";
shell_exec($cmd);
if($_FILES["uploadFile"]["error"]> 0 ){
    echo "ERROR.\n";
}
else{
    #echo $_FILES["uploadFile"]["name"]."\n";
    $fname = $dirPath."/input.txt";
    #echo $fname."\n";
    move_uploaded_file($_FILES["uploadFile"]["tmp_name"], $fname);
    shell_exec("chmod -Rf 777 $dirPath");
}

echo "<script type='text/javascript'>window.location.href='http://120.126.17.186:8080/cloudsystem/view.php?jobId=".$dirname."'</script>";

?>
