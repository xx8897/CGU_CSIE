<html>

<form method="post" action="exe.php" enctype="multipart/form-data">

<input type="file" name="uploadFile">
<input type="submit" value="Submit">

</form>


</html>
