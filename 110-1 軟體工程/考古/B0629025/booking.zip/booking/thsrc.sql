-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- 主機： 127.0.0.1
-- 產生時間： 
-- 伺服器版本： 10.4.6-MariaDB
-- PHP 版本： 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `thsrc`
--

-- --------------------------------------------------------

--
-- 資料表結構 `booking`
--

CREATE TABLE `booking` (
  `bookingId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `trainNumber` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  `startTime` varchar(50) NOT NULL,
  `endTime` varchar(50) NOT NULL,
  `startStation` varchar(50) NOT NULL,
  `endStation` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `booking`
--

INSERT INTO `booking` (`bookingId`, `userId`, `trainNumber`, `date`, `startTime`, `endTime`, `startStation`, `endStation`) VALUES
(8, 1, '111', '2019/08/08', '20:00', '21:00', '11', '12'),
(9, 1, '111', '2019/08/08', '13:00', '18:00', '4', '9'),
(10, 1, '111', '2019/08/08', '12:00', '21:00', '3', '12');

-- --------------------------------------------------------

--
-- 資料表結構 `train`
--

CREATE TABLE `train` (
  `trainId` int(11) NOT NULL,
  `trainNumber` int(11) NOT NULL,
  `nangang` varchar(30) NOT NULL COMMENT '南港',
  `taipei` varchar(30) NOT NULL COMMENT '台北',
  `itabashi` varchar(30) NOT NULL COMMENT '板橋',
  `taoyuan` varchar(30) NOT NULL COMMENT '桃園',
  `hsinchu` varchar(30) NOT NULL COMMENT '新竹',
  `miaoli` varchar(30) NOT NULL COMMENT '苗栗',
  `taichung` varchar(30) NOT NULL COMMENT '台中',
  `changhua` varchar(30) NOT NULL COMMENT '彰化',
  `yunlin` varchar(30) NOT NULL COMMENT '雲林',
  `chiayi` varchar(30) NOT NULL COMMENT '嘉義',
  `tainan` varchar(30) NOT NULL COMMENT '台南',
  `zuoying` varchar(30) NOT NULL COMMENT '左營',
  `isNorth` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `train`
--

INSERT INTO `train` (`trainId`, `trainNumber`, `nangang`, `taipei`, `itabashi`, `taoyuan`, `hsinchu`, `miaoli`, `taichung`, `changhua`, `yunlin`, `chiayi`, `tainan`, `zuoying`, `isNorth`) VALUES
(1, 111, '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', 1),
(2, 222, '21:00', '20:00', '19:00', '18:00', '17:00', '16:00', '15:00', '14:00', '13:00', '12:00', '11:00', '10:00', 0);

-- --------------------------------------------------------

--
-- 資料表結構 `user`
--

CREATE TABLE `user` (
  `userId` int(11) NOT NULL,
  `account` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `user`
--

INSERT INTO `user` (`userId`, `account`, `password`) VALUES
(1, 'account', '1234');

--
-- 已傾印資料表的索引
--

--
-- 資料表索引 `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`bookingId`),
  ADD KEY `userId` (`userId`);

--
-- 資料表索引 `train`
--
ALTER TABLE `train`
  ADD PRIMARY KEY (`trainId`);

--
-- 資料表索引 `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userId`);

--
-- 在傾印的資料表使用自動遞增(AUTO_INCREMENT)
--

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `booking`
--
ALTER TABLE `booking`
  MODIFY `bookingId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `train`
--
ALTER TABLE `train`
  MODIFY `trainId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `user`
--
ALTER TABLE `user`
  MODIFY `userId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- 已傾印資料表的限制式
--

--
-- 資料表的限制式 `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `booking_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`userId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
