#include <pthread.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include <sys/time.h>

#define length 1000000
#define threadNumber 4

//the shared address space
int acc;
int count;
pthread_mutex_t mylock;


int A[length];

void initial(int *A)
{
	int i;
	//A = malloc( length * sizeof(int) );
	for(i=0;i<length;i++)
		A[i] = 1;
}

void findPrime(int *A)
{
	int i, j;
	for(i=2;i<sqrt(length);i++)
	{
		if(A[i] == 1)
		{	
			j=i*i;
			while(j<length)
			{
				A[j]=0;
				j+=i;
			}	
		}
	}
}

void *
child_thread (p)
	void *p;
{
	int *key;

	key = (int*) p;

	//printf ("Child thread: to accumulate %d\n", *key);

	//the critical section with mutual-exclusive synchronization
	pthread_mutex_lock (&mylock);
	{
		findPrime(A);
		count = count+1;
	}
	pthread_mutex_unlock (&mylock);
}//child_thread

void printPrime(int *A)
{
	int i,pc;
	pc = 0;
	for(i=2;i<length;i++)
	{
		if(A[i] == 1)
			pc++;
			
			//cout <<i<<endl;
	}
	printf("Prime Number in %d: %d\t", length, pc);
}

main ()
{
	int i;
    double cpu_time_used;
	struct timeval seqStart, seqEnd;    // 測量時間
    struct timeval paraStart, paraEnd;
	int seqTimer, paraTimer;
	initial(A);
	pthread_t thread_id[threadNumber];

	//initialize shared data
	//acc = 0;
	count = 0;	

	//initialize locks
	pthread_mutex_init (&mylock, NULL);
	gettimeofday(&seqStart,NULL);
	
	//fork child threads
	for (i=0;i<threadNumber;i++)
		pthread_create (&(thread_id[i]), NULL, child_thread, &(A[i*(length/threadNumber)]));
	
	while (count<threadNumber);
	
	gettimeofday(&seqEnd,NULL);
	seqTimer = (seqEnd.tv_sec-seqStart.tv_sec)*1000000+seqEnd.tv_usec-seqStart.tv_usec;
	double time = seqTimer/1000000.0;
	
	printf ("Parallel time = %f (s)\n", time);

	printPrime(A);
	printf("\n");

	return 0;
}//main ()
