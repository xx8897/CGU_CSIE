<?php



$list = scandir("/share");

array_shift($list);
array_shift($list);
#print_r($list);

foreach($list as $d){
	$state = "/share/".$d."/computing";
	$output = "/share/".$d."/output.txt";
	$input = "/share/".$d."/input.txt";
	if(!file_exists($state) || !file_exists($output)){
		shell_exec("touch $state");
		
		$outfile = fopen($output, "w");
		if(file_exists($input)){
			sleep(10);
			$file = file_get_contents($input,true);
			$line = md5($file);
			fwrite($outfile,$line);
		}
		else
		{
			fwrite($outfile,"something wnt wrong!!!\n");
		}
		fclose($outfile);
		break;
	}
}

?>
