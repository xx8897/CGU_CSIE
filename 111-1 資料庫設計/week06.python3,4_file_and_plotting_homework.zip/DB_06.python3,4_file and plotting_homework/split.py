
str = " fp = open(file, "r", encoding = 'UTF-8')"
print (str.split( ))