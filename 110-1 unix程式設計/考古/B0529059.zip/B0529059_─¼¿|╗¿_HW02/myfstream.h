#ifndef myfstream_h

#define myfstream_h
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

class myfstream
{
	public:
	size_t fileID;
	void openFile(const char *filename);
	void closeFile();
	void readFile(char *str,int stringsize);
	void writeFile(const char *str,int stringsize);
	myfstream& operator<<(char *str);
	myfstream& operator>>(char *str);
};

#endif

