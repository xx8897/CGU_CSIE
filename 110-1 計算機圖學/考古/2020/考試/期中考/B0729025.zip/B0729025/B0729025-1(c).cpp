#include<stdlib.h>
#include<stdio.h>
#include<time.h>
#include<GL/glut.h>
#include<math.h>

void init (void){
	glClearColor (1.0, 1.0, 1.0, 0.0);  // Set display-window color to white.
	glMatrixMode (GL_PROJECTION);       // Set projection parameters.
	gluOrtho2D (-100.0, 100.0, -100.0, 100.0);
}

const GLfloat pi=3.1415926536f;
const int n=3600;
const float DEG2RAD = 3.14159/180;

void lineSegment (void){
	glClear (GL_COLOR_BUFFER_BIT);  // Clear display window.
	//����
    glColor3f(1.0,0.2,0.0);
		glBegin (GL_POLYGON);
		glVertex2i (-45,-40);
		glVertex2i (-45,-30);
		glVertex2i (-90,0);
	glEnd ( );
	float x10radius=3;
	float y10radius=6;
    glBegin(GL_POLYGON);
    glColor3f(1.0,0.2,0.0);
	for (int i=0; i < 360; i++){
		//convert degrees into radians
		float degInRad = i*DEG2RAD;
		glVertex2f(-86+cos(degInRad)*x10radius,2+sin(degInRad)*y10radius);
	}
	glEnd();
	//�}1 
    float x5radius=6;
	float y5radius=10;
    glBegin(GL_POLYGON);
    glColor3f(1.0,0.4,0.0);
	for (int i=0; i < 360; i++){
		//convert degrees into radians
		float degInRad = i*DEG2RAD;
		glVertex2f(-43+cos(degInRad)*x5radius,-62+sin(degInRad)*y5radius);
	}
	glEnd();
	//�}2
    glBegin(GL_POLYGON);
    glColor3f(1.0,0.4,0.0);
	for (int i=0; i < 360; i++){
		//convert degrees into radians
		float degInRad = i*DEG2RAD;
		glVertex2f(-28+cos(degInRad)*x5radius,-65+sin(degInRad)*y5radius);
	}
	glEnd();
	//�}3
    glBegin(GL_POLYGON);
    glColor3f(1.0,0.4,0.0);
	for (int i=0; i < 360; i++){
		//convert degrees into radians
		float degInRad = i*DEG2RAD;
		glVertex2f(-5+cos(degInRad)*x5radius,-65+sin(degInRad)*y5radius);
	}
	glEnd();
	//�}4
    glBegin(GL_POLYGON);
    glColor3f(1.0,0.4,0.0);
	for (int i=0; i < 360; i++){
		//convert degrees into radians
		float degInRad = i*DEG2RAD;
		glVertex2f(10+cos(degInRad)*x5radius,-62+sin(degInRad)*y5radius);
	}
	glEnd();
	//���� 
    float x4radius=45;
	float y4radius=35;
    glBegin(GL_POLYGON);
    glColor3f(1.0,0.4,0.0);
	for (int i=0; i < 360; i++){
		//convert degrees into radians
		float degInRad = i*DEG2RAD;
		glVertex2f(-15+cos(degInRad)*x4radius,-30+sin(degInRad)*y4radius);
	}
	glEnd();
	//�O��
	float x3radius=55;
	float y3radius=50;
    glBegin(GL_POLYGON);
    glColor3f(1.0,0.2,0.0);
	for (int i=0; i < 360; i++){
		//convert degrees into radians
		float degInRad = i*DEG2RAD;
		glVertex2f(cos(degInRad)*x3radius,15+sin(degInRad)*y3radius);
	}
	glEnd();
	//�O����
	const GLfloat R=15; //��Υb�| 
	glBegin(GL_POLYGON);
		glColor3f(1.0,0.2,0.0);
		for (int i = 1; i <= n; i++){
			glVertex2f(-50+R*cos(2*pi/n*i),22+R*sin(2*pi/n*i));
		}
    glEnd();
	const GLfloat R1=13; //��Υb�| 
	glBegin(GL_POLYGON);
		glColor3f(1.0,0.2,0.0);
		for (int i = 1; i <= n; i++){
			glVertex2f(-48+R1*cos(2*pi/n*i),35+R1*sin(2*pi/n*i));
		}
    glEnd(); 
    const GLfloat R2=17; //��Υb�| 
	glBegin(GL_POLYGON);
		glColor3f(1.0,0.2,0.0);
		for (int i = 1; i <= n; i++){
			glVertex2f(-35+R2*cos(2*pi/n*i),50+R2*sin(2*pi/n*i));
		}
    glEnd();
    const GLfloat R3=16; //��Υb�| 
	glBegin(GL_POLYGON);
		glColor3f(1.0,0.2,0.0);
		for (int i = 1; i <= n; i++){
			glVertex2f(-20+R3*cos(2*pi/n*i),60+R3*sin(2*pi/n*i));
		}
    glEnd();
    //
    glBegin(GL_POLYGON);
		glColor3f(1.0,0.2,0.0);
		for (int i = 1; i <= n; i++){
			glVertex2f(3+R3*cos(2*pi/n*i),63+R3*sin(2*pi/n*i));
		}
    glEnd();
    //
    glBegin(GL_POLYGON);
		glColor3f(1.0,0.2,0.0);
		for (int i = 1; i <= n; i++){
			glVertex2f(25+R2*cos(2*pi/n*i),55+R2*sin(2*pi/n*i));
		}
    glEnd();
    //
    glBegin(GL_POLYGON);
		glColor3f(1.0,0.2,0.0);
		for (int i = 1; i <= n; i++){
			glVertex2f(40+R1*cos(2*pi/n*i),47+R1*sin(2*pi/n*i));
		}
    glEnd();
    //
    glBegin(GL_POLYGON);
		glColor3f(1.0,0.2,0.0);
		for (int i = 1; i <= n; i++){
			glVertex2f(47+R3*cos(2*pi/n*i),30+R3*sin(2*pi/n*i));
		}
    glEnd();
    //
    glBegin(GL_POLYGON);
		glColor3f(1.0,0.2,0.0);
		for (int i = 1; i <= n; i++){
			glVertex2f(50+R*cos(2*pi/n*i),10+R*sin(2*pi/n*i));
		}
    glEnd();
    //
    glBegin(GL_POLYGON);
		glColor3f(1.0,0.2,0.0);
		for (int i = 1; i <= n; i++){
			glVertex2f(45+R3*cos(2*pi/n*i),-10+R3*sin(2*pi/n*i));
		}
    glEnd();
    //
    const GLfloat R4=14; //��Υb�| 
    glBegin(GL_POLYGON);
		glColor3f(1.0,0.2,0.0);
		for (int i = 1; i <= n; i++){
			glVertex2f(35+R4*cos(2*pi/n*i),-25+R4*sin(2*pi/n*i));
		}
    glEnd();
    //
    glBegin(GL_POLYGON);
		glColor3f(1.0,0.2,0.0);
		for (int i = 1; i <= n; i++){
			glVertex2f(15+R*cos(2*pi/n*i),-28+R*sin(2*pi/n*i));
		}
    glEnd();
    //
    glBegin(GL_POLYGON);
		glColor3f(1.0,0.2,0.0);
		for (int i = 1; i <= n; i++){
			glVertex2f(-5+R*cos(2*pi/n*i),-30+R*sin(2*pi/n*i));
		}
    glEnd();
    //
    glBegin(GL_POLYGON);
		glColor3f(1.0,0.2,0.0);
		for (int i = 1; i <= n; i++){
			glVertex2f(-25+R*cos(2*pi/n*i),-28+R*sin(2*pi/n*i));
		}
    glEnd();
    //
    glBegin(GL_POLYGON);
		glColor3f(1.0,0.2,0.0);
		for (int i = 1; i <= n; i++){
			glVertex2f(-40+R*cos(2*pi/n*i),-15+R*sin(2*pi/n*i));
		}
    glEnd();
    //
    glBegin(GL_POLYGON);
		glColor3f(1.0,0.2,0.0);
		for (int i = 1; i <= n; i++){
			glVertex2f(-50+R*cos(2*pi/n*i),R*sin(2*pi/n*i));
		}
    glEnd();
	//�y 
    float xradius=45;
	float yradius=40;
    glBegin(GL_POLYGON);
    glColor3f(1.0,0.4,0.0);
	for (int i=0; i < 360; i++){
		//convert degrees into radians
		float degInRad = i*DEG2RAD;
		glVertex2f(cos(degInRad)*xradius,15+sin(degInRad)*yradius);
	}
	glEnd();
	//���� 
	float x1radius=8;
	float y1radius=8;
    glBegin(GL_POLYGON);
    glColor3f(1.0,0.4,0.0);
	for (int i=0; i < 360; i++){
		//convert degrees into radians
		float degInRad = i*DEG2RAD;
		glVertex2f(-37+cos(degInRad)*x1radius,40+sin(degInRad)*y1radius);
	}
	glEnd();
	//�k�� 
	float x2radius=8;
	float y2radius=8;
    glBegin(GL_POLYGON);
    glColor3f(1.0,0.4,0.0);
	for (int i=0; i < 360; i++){
		//convert degrees into radians
		float degInRad = i*DEG2RAD;
		glVertex2f(37+cos(degInRad)*x2radius,40+sin(degInRad)*y2radius);
	}
	glEnd();
	//�k��
	const GLfloat R6=5; //��Υb�| 
	const GLfloat R7=2; //��Υb�| 
    glBegin(GL_POLYGON);
		glColor3f(0.5,0.0,0.0); 
		for (int i=1; i<=n;i++){
			glVertex2f(-20+R6*cos(2*pi/n*i),26+R6*sin(2*pi/n*i));
		}
    glEnd(); 
	glBegin(GL_POLYGON);
		glColor3f(1.0,1.0,1.0); 
		for (int i=1; i<=n;i++){
			glVertex2f(-20+R7*cos(2*pi/n*i),28+R7*sin(2*pi/n*i));
		}
    glEnd(); 
    glBegin(GL_POLYGON);
		glColor3f(1.0,1.0,1.0); 
		for (int i=1; i<=n;i++){
			glVertex2f(-20+R7*cos(2*pi/n*i),24+R7*sin(2*pi/n*i));
		}
    glEnd();
	//����
	glBegin(GL_POLYGON);
		glColor3f(0.5,0.0,0.0); 
		for (int i=1; i<=n;i++){
			glVertex2f(20+R6*cos(2*pi/n*i),26+R6*sin(2*pi/n*i));
		}
    glEnd(); 
	glBegin(GL_POLYGON);
		glColor3f(1.0,1.0,1.0); 
		for (int i=1; i<=n;i++){
			glVertex2f(20+R7*cos(2*pi/n*i),28+R7*sin(2*pi/n*i));
		}
    glEnd(); 
    glBegin(GL_POLYGON);
		glColor3f(1.0,1.0,1.0); 
		for (int i=1; i<=n;i++){
			glVertex2f(20+R7*cos(2*pi/n*i),24+R7*sin(2*pi/n*i));
		}
    glEnd(); 
    //�L��
	float x11radius=6;
	float y11radius=10;
    glBegin(GL_LINE_STRIP);
    glColor3f(0.0,0.0,0.0);
	for (int i=0; i < 360; i++){
		//convert degrees into radians
		float degInRad = i*DEG2RAD;
		glVertex2f(-6+cos(degInRad)*x11radius,sin(degInRad)*y11radius);
	}
	glEnd();
	glBegin(GL_LINE_STRIP);
    glColor3f(0.0,0.0,0.0);
	for (int i=0; i < 360; i++){
		//convert degrees into radians
		float degInRad = i*DEG2RAD;
		glVertex2f(6+cos(degInRad)*x11radius,sin(degInRad)*y11radius);
	}
	glEnd(); 
	//
	float x20radius=5;
	float y20radius=6;
	glBegin(GL_POLYGON);
    glColor3f(1.0,0.4,0.0);
	for (int i=0; i < 360; i++){
		//convert degrees into radians
		float degInRad = i*DEG2RAD;
		glVertex2f(-10+cos(degInRad)*x20radius,sin(degInRad)*y20radius);
	}
	glEnd(); 
	glBegin(GL_POLYGON);
    glColor3f(1.0,0.4,0.0);
	for (int i=0; i < 360; i++){
		//convert degrees into radians
		float degInRad = i*DEG2RAD;
		glVertex2f(10+cos(degInRad)*x20radius,sin(degInRad)*y20radius);
	}
	glEnd();
	glBegin(GL_POLYGON);
    glColor3f(1.0,0.4,0.0);
	for (int i=0; i < 360; i++){
		//convert degrees into radians
		float degInRad = i*DEG2RAD;
		glVertex2f(-9+cos(degInRad)*x20radius,5+sin(degInRad)*y20radius);
	}
	glEnd();  
	glBegin(GL_POLYGON);
    glColor3f(1.0,0.4,0.0);
	for (int i=0; i < 360; i++){
		//convert degrees into radians
		float degInRad = i*DEG2RAD;
		glVertex2f(9+cos(degInRad)*x20radius,5+sin(degInRad)*y20radius);
	}
	glEnd();  
	//��l
	float x6radius=6;
	float y6radius=5;
    glBegin(GL_POLYGON);
    glColor3f(0.5,0.0,0.0);
	for (int i=0; i < 360; i++){
		//convert degrees into radians
		float degInRad = i*DEG2RAD;
		glVertex2f(cos(degInRad)*x6radius,8+sin(degInRad)*y6radius);
	}
	glEnd();
	//�|��
	const GLfloat R8=5; //��Υb�| 
    glBegin(GL_POLYGON);
		glColor3f(1.0,0.9,1.0);
		for (int i = 1; i <= n; i++){
			glVertex2f(20+R8*cos(2*pi/n*i),R8*sin(2*pi/n*i));
		}
    glEnd();
    glBegin(GL_POLYGON);
		glColor3f(1.0,0.9,1.0);
		for (int i = 1; i <= n; i++){
			glVertex2f(-20+R8*cos(2*pi/n*i),R8*sin(2*pi/n*i));
		}
    glEnd();
    //���G�l
	glColor3f (0.0, 0.0, 0.0);
	glBegin (GL_LINES);
	glVertex2i (-32,4);
	glVertex2i (-21,2);
	glEnd ( );
	glBegin (GL_LINES);
	glVertex2i (-32,0);
	glVertex2i (-21,-1);
	glEnd ( );  
	glBegin (GL_LINES);
	glVertex2i (-32,-4);
	glVertex2i (-21,-3);
	glEnd ( );
	//�k�G�l
	glColor3f (0.0, 0.0, 0.0);
	glBegin (GL_LINES);
	glVertex2i (32,4);
	glVertex2i (21,2);
	glEnd ( );
	glBegin (GL_LINES);
	glVertex2i (32,0);
	glVertex2i (21,-1);
	glEnd ( );  
	glBegin (GL_LINES);
	glVertex2i (32,-4);
	glVertex2i (21,-3);
	glEnd ( );
	
    glFlush();
}

int main (int argc, char** argv){
	glutInit (&argc, argv); // Initialize GLUT.
	glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);   // Set display mode.
	glutInitWindowPosition (100,50);   // Set top-left display-window position.
	glutInitWindowSize (500, 500);// Set display-window width and height.
	glutCreateWindow ("B0729025_3"); // Create display window.
	init ( );
	glutDisplayFunc (lineSegment); // Send graphics to display window.
	glutMainLoop ( );  // Display everything and wait.
}
