#!/bin/bash -x

#SBATCH -J slurmtest                   #作業名為 slurmtest
#SBATCH -o slurmtest.out               # 輸出結果檔名為slurmtest.out
#SBATCH --qos=debug               #使用的QoS為 debug
#SBATCH -N 4                     #申請4個節點 
#SBATCH --ntasks-per-node=20     #每個節點申請20核心
which mpirun
mpirun mpihello.out 
