int mult(int x,int y);
int
calculate (int a, int b, int c)
{
	int S;

	S = a;
	S += mult(b, c);	//mult(b,c) performs b*c

	return S;
}

