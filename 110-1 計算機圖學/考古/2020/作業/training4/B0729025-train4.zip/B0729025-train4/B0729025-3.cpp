#include<stdlib.h>
#include<stdio.h>
#include<time.h>
#include<GL/glut.h>
#include<math.h>

void init (void){
	glClearColor (1.0, 1.0, 1.0, 0.0);  // Set display-window color to white.
	glMatrixMode (GL_PROJECTION);       // Set projection parameters.
	gluOrtho2D (-100.0, 100.0, -100.0, 100.0);
}

const GLfloat R=50; //�b�| 
const GLfloat pi=3.1415926536f;
const GLfloat n=3;

void lineSegment (void){
	glClear (GL_COLOR_BUFFER_BIT);  // Clear display window.
	//����T���� 
	glBegin(GL_POLYGON);
		glColor3f (1.0, 0.0, 0.0);
		for (int i=0;i<n; i++){
			glVertex2f(R*cos(-0.53+2*pi/n*i),R*sin(-0.53+2*pi/n*i));
		}
    glEnd();
    //���T���� 
    glBegin(GL_POLYGON);
		glColor3f (0.0, 1.0, 0.0);
		for (int i=0;i<n; i++){
			glVertex2f(0.5*R*cos(-0.53+2*pi/n*i),0.5*R*sin(-0.53+2*pi/n*i));
		}
    glEnd();
	glFlush ( );
}

int main (int argc, char** argv){
	glutInit (&argc, argv); // Initialize GLUT.
	glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB); // Set display mode.
	glutInitWindowPosition (100,100); // Set top-left display-window position.
	glutInitWindowSize (500,500);// Set display-window width and height.
	glutCreateWindow ("training-3"); // Create display window.
	init ( ); // Execute initialization procedure.
	glutDisplayFunc (lineSegment); // Send graphics to display window.
	glutMainLoop ( );  // Display everything and wait.
}
