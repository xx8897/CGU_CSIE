#include<stdlib.h>
#include<stdio.h>
#include<time.h>
#include<GL/glut.h>
#include<math.h>
#include <time.h>

void init (void){
	glClearColor (1.0, 1.0, 1.0, 0.0);  // Set display-window color to white.
	glMatrixMode (GL_PROJECTION);       // Set projection parameters.
	gluOrtho2D (100.0, -100.0, 100.0, -100.0);
}

const int n = 2000;
//const GLfloat R=100; //��Υb�| 
const GLfloat pi = 3.1415926536f;

void lineSegment (void){
	srand(time(0));
	glClear (GL_COLOR_BUFFER_BIT);  // Clear display window.
	float r=255.0;
	float g=0.0;
	float b=0.0;
	for(GLfloat R=100;R>0;R--){
		glColor3f (r/255.0,g/255.0,b/255.0);
		glBegin (GL_POINTS);/////////////GL_POINTS
			for(int i=0;i<3600;i++){
				glVertex2f(R*cos(2*pi/n*i),R*sin(2*pi/n*i));
			}
		r=r-2.55;
		g=g+2.55;
		b=b+1.27;
		glEnd ( );		
	}

	glFlush();
}

int main (int argc, char** argv){
	glutInit (&argc, argv); // Initialize GLUT.
	glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);   // Set display mode.
	glutInitWindowPosition (100,50);   // Set top-left display-window position.
	glutInitWindowSize (500, 500);// Set display-window width and height.
	glutCreateWindow ("B0729025_training3-2"); // Create display window.
	init ( );
	glutDisplayFunc (lineSegment); // Send graphics to display window.
	glutMainLoop ( );  // Display everything and wait.
}
