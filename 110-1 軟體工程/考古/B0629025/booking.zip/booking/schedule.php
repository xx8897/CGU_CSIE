<?php include('header.php') ?>

<?php
    if (!empty($_GET['date'])) {
      $date = $_GET['date'];
    	$south = "select * from train where isNorth = 0";
    	$southStatement = $pdo->prepare($south);
      $southStatement->execute();
			$southData = $southStatement->fetchAll(PDO::FETCH_ASSOC);

    	$north = "select * from train where isNorth = 1";
    	$northStatement = $pdo->prepare($north);
      $northStatement->execute();
      $northData = $northStatement->fetchAll(PDO::FETCH_ASSOC);
    }
?>

<section class="mt-5 content">
  <h1 class="font-weight-light text-center text-lg-left mb-0" style="font-family:微軟正黑體" >時刻表</h1>
  <hr class="mt-2 mb-5">

	<form method="get">
	  <div class="col-sm-6 form-group row">
	    <label class="col-sm-2 col-form-label">日期</label>
	    <div class="col-sm-8">
	       <input  name="date" class="datepicker form-control" value="<?=empty($_GET['date']) ? '' : $_GET['date']?>" />
	    </div>
	    <button type="submit" class="btn btn-primary btn-block col-sm-2">查詢車次</button>
	  </div>
  </form>

  <?php
    if (!empty($_GET['date'])) {
  ?>
  <h1 class="font-weight-light text-center text-lg-left mb-0">南下</h1>
    <hr>

    <table class="table">
      <thead class="thead-dark">
        <tr>
          <th scope="col">車次</th>
          <th scope="col">南港站</th>
          <th scope="col">台北站</th>
          <th scope="col">板橋站</th>
          <th scope="col">桃園站</th>
          <th scope="col">新竹站</th>
          <th scope="col">苗栗站</th>
          <th scope="col">台中站</th>
          <th scope="col">彰化站</th>
          <th scope="col">雲林站</th>
          <th scope="col">嘉義站</th>
          <th scope="col">台南站</th>
          <th scope="col">左營站</th>
        </tr>
      </thead>
      <tbody>
      <?php
        foreach ($southData as $data) {
      ?>
        <tr>
          <th scope="row"><?=$data['trainNumber']?></th>
          <td><?=$data['nangang']?></td>
          <td><?=$data['taipei']?></td>
          <td><?=$data['itabashi']?></td>
          <td><?=$data['taoyuan']?></td>
          <td><?=$data['hsinchu']?></td>
          <td><?=$data['miaoli']?></td>
          <td><?=$data['taichung']?></td>
          <td><?=$data['changhua']?></td>
          <td><?=$data['yunlin']?></td>
          <td><?=$data['chiayi']?></td>
          <td><?=$data['tainan']?></td>
          <td><?=$data['zuoying']?></td>
        </tr>
      <?php
        }
      ?>
      <tbody>
    </table>

    <h1 class="font-weight-light text-center text-lg-left mb-0">北上</h1>
    <hr>
    <table class="table">
      <thead class="thead-dark">
        <tr>
          <th scope="col">車次</th>
          <th scope="col">左營站</th>
          <th scope="col">台南站</th>
          <th scope="col">嘉義站</th>
          <th scope="col">雲林站</th>
          <th scope="col">彰化站</th>
          <th scope="col">台中站</th>
          <th scope="col">苗栗站</th>
          <th scope="col">新竹站</th>
          <th scope="col">桃園站</th>
          <th scope="col">板橋站</th>
          <th scope="col">台北站</th>
          <th scope="col">南港站</th>
        </tr>
      </thead>
      <tbody>
        <?php
          foreach ($northData as $data) {
        ?>
          <tr>
            <th scope="row"><?=$data['trainNumber']?></th>
            <td><?=$data['nangang']?></td>
            <td><?=$data['taipei']?></td>
            <td><?=$data['itabashi']?></td>
            <td><?=$data['taoyuan']?></td>
            <td><?=$data['hsinchu']?></td>
            <td><?=$data['miaoli']?></td>
            <td><?=$data['taichung']?></td>
            <td><?=$data['changhua']?></td>
            <td><?=$data['yunlin']?></td>
            <td><?=$data['chiayi']?></td>
            <td><?=$data['tainan']?></td>
            <td><?=$data['zuoying']?></td>
          </tr>
        <?php
          }
        ?>
      <tbody>
    </table>
  <?php
    }
  ?>

</section>


