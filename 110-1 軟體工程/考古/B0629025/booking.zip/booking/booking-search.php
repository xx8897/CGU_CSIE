<?php include('header.php') ?>

<?php
	$sql = "select * from booking where userId = :userId";
	$statement = $pdo->prepare($sql);
	$statement->execute(array('userId' => $_SESSION['userId']));
	$data = $statement->fetchAll(PDO::FETCH_ASSOC);
?>


<!--取消-->
<?php
if (!empty($_POST['delete'])) {
print_r($_POST['startTime']);
	$sql = "DELETE FROM booking where bookingId = :bookingId";
	$statement = $pdo->prepare($sql);
	$statement->execute(array(
	  'bookingId' => $_POST['bookingId']
  ));
  echo ("<script>window.alert('已取消');window.location.href='booking-search.php';</script>");
}
?>

<section class="mt-5 content">
  <h1 class="font-weight-light text-center text-lg-left mb-0">訂票紀錄查詢</h1>
  <hr class="mt-2 mb-5">

  <table class="table">
    <thead class="thead-dark">
      <tr>
        <th scope="col">車次</th>
        <th scope="col">乘車日期</th>
        <th scope="col">出發站</th>
        <th scope="col">出發時間</th>
        <th scope="col">抵達站</th>
        <th scope="col">抵達時間</th>
        <th scope="col">動作</th>
      </tr>
    </thead>
    <tbody>
    <?php
      foreach ($data as $key=>$item) {
    ?>
      <tr>
        <th scope="row"><?=$item['trainNumber']?></th>
        <td><?=$item['date']?></td>
        <td><?=getStation($item['startStation'])?></td>
        <td><?=$item['startTime']?></td>
        <td><?=getStation($item['endStation'])?></td>
        <td><?=$item['endTime']?></td>
        <th scope="col" class="row">
          <form id="edit<?=$item['bookingId']?>" method="post" style="padding: 0 10px;">
            <input type="hidden" name="edit" value="1">
            <input type="hidden" name="bookingId" value="<?=$item['bookingId']?>">
            <a href="#" onclick="window.location.href='booking.php?bookingId=<?=$item['bookingId']?>'">修改</a>
          </form>
          <form id="delete<?=$item['bookingId']?>" method="post" style="padding: 0 10px;">
            <input type="hidden" name="delete" value="1">
            <input type="hidden" name="bookingId" value="<?=$item['bookingId']?>">
            <a href="#" class="text-danger" onclick="document.getElementById('delete<?=$item['bookingId']?>').submit();">取消</a>
          </form>
        </th>
      </tr>
    <?php
      }
    ?>
    </tbody>
  </table>
</section>

