#include"myfstream.h"

int main()
{
	myfstream ifile,ofile;
	char data[15];
	
	ifile.openFile( "test1.txt" );
	ofile.openFile( "test2.txt" );
	
	ifile >> data;
	ofile << data;
	
	ifile.closeFile();
	ofile.closeFile();
	
	return 0;
}
