<?php include('default.php') ?>
<?php include('db.php') ?>
<?php

  if (!empty($_POST['account']) && !empty($_POST['password'])) {
	  $account = $_POST['account'];
	  $password = $_POST['password'];
	  $sql= "select * from user where account = :account && password = :password";

	  // 運行 SQL
	  $statement = $pdo->prepare($sql);
	  $statement->execute(array(
	      'account' => $account,
	      'password' => $password
	  ));
	  $row = $statement->fetch();
	  if (!empty($row)) {
	    $_SESSION['userId'] = $row['userId'];
	    $message = '登入中...請稍後';
	    echo '<meta http-equiv=REFRESH CONTENT=1;url=schedule.php>';
	  } else {
	    $message = '帳號密碼錯誤';
	  }
	}
 ?>

<body>
  <div class="container">
    <div class="row">
      <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
        <div class="card card-signin my-5">
          <div class="card-body">
            <form method="post">
              <div class="form-group">
                <label>帳號</label>
                <input name="account" type="text"  class="form-control" placeholder="Account" required autofocus>
              </div>
              <div class="form-label-group">
                <label>密碼</label>
                <input name="password" type="password" class="form-control" placeholder="Password" required>
              </div>
              <div class="row center">
                <span class="text-danger mt-2">
                  <?php if (!empty($message)) { echo $message; } ?>
                <span>
              </div>
              <button class="btn btn-lg btn-primary btn-block m-t-32" type="submit">登入</button>
              <hr class="my-4">
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
