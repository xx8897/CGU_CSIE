#include<stdlib.h>
#include<stdio.h>
#include<time.h>
#include<GL/glut.h>
#include<math.h>

void init (void){
	glClearColor (1.0, 1.0, 1.0, 0.0);  // Set display-window color to white.
	glMatrixMode (GL_PROJECTION);       // Set projection parameters.
	gluOrtho2D (-100.0, 100.0, -100.0, 100.0);
}


const int n = 3600;
const GLfloat R = 15; //��Υb�| 
const GLfloat pi = 3.1415926536f;

void lineSegment (void){
	/////////////////////////////�Ĥ@��
	glClear (GL_COLOR_BUFFER_BIT);  // Clear display window.
	glColor3f (0.0, 0.0, 1.0);
	glBegin (GL_LINE_STRIP);
		glVertex2i (-90,60);
		glVertex2i (-90,90);
		glVertex2i (-45,90);
		glVertex2i (-45,60);
		glVertex2i (-90,60);
	glEnd ( ); 
	/////////////////////////////�ĤG��
	glColor3f (0.0, 1.0, 0.0);
	glBegin (GL_QUADS);
		glVertex2i (-90,20);
		glVertex2i (-90,50);
		glVertex2i (-45,50);
		glVertex2i (-45,20);
		glVertex2i (-90,20);
	glEnd ( ); 
	/////////////////////////////�ĤT��
	glColor3f (0.0, 0.0, 1.0);
	glBegin (GL_QUADS);
		glVertex2i (-90,10);
		glVertex2i (-90,-20);
		glVertex2i (-45,-20);
		glVertex2i (-45,10);
		glVertex2i (-90,10);
	glEnd ( );
	glColor3f (1.0, 0.0, 0.0);
	glLineWidth(2);
	glBegin (GL_LINE_STRIP);
		glVertex2i (-90,10);
		glVertex2i (-90,-20);
		glVertex2i (-45,-20);
		glVertex2i (-45,10);
		glVertex2i (-90,10);
	glEnd ( );
	////////////////////////////�ĥ|�� 
	glLineWidth(4);
	//�Ŧ� 
	glBegin(GL_LINE_LOOP);
		glColor3f(0.0,0.0,1.0);
		for (int i = 1; i <= n; i++){
			glVertex2f(-10+R*cos(2*pi/n*i),40+R*sin(2*pi/n*i));
		}
    glEnd();
	//�¦� 
    glBegin(GL_LINE_LOOP);
		glColor3f(0.0,0.0,0.0); 
		for (int i = 1; i <= n; i++){
			glVertex2f(25+R*cos(2*pi/n*i),40+R*sin(2*pi/n*i));
		}
    glEnd();
    //���� 
    glBegin(GL_LINE_LOOP);
		glColor3f(1.0,0.0,0.0); 
		for (int i = 1; i <= n; i++){
			glVertex2f(60+R*cos(2*pi/n*i),40+R*sin(2*pi/n*i));
		}
    glEnd();
    //���� 
    glBegin(GL_LINE_LOOP);
		glColor3f(1.0,1.0,0.0); 
		for (int i = 1; i <= n; i++){
			glVertex2f(6+R*cos(2*pi/n*i),25+R*sin(2*pi/n*i));
		}
    glEnd();
    //��� 
    glBegin(GL_LINE_LOOP);
		glColor3f(0.0,1.0,0.0); 
		for (int i = 1; i <= n; i++){
			glVertex2f(42+R*cos(2*pi/n*i),25+R*sin(2*pi/n*i));
		}
    glEnd();
    glFlush();
}

int main (int argc, char** argv){
	glutInit (&argc, argv); // Initialize GLUT.
	glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);   // Set display mode.
	glutInitWindowPosition (100,50);   // Set top-left display-window position.
	glutInitWindowSize (500, 500);// Set display-window width and height.
	glutCreateWindow ("B0729025_HW1"); // Create display window.
	init ( );
	glutDisplayFunc (lineSegment); // Send graphics to display window.
	glutMainLoop ( );  // Display everything and wait.
}
