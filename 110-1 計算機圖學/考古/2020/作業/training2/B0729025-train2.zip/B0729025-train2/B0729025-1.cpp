#include<stdlib.h>
#include<stdio.h>
#include<time.h>
#include<GL/glut.h>
#include<math.h>

void init (void){
	glClearColor (1.0, 1.0, 1.0, 0.0);  // Set display-window color to white.
	glMatrixMode (GL_PROJECTION);       // Set projection parameters.
	gluOrtho2D (-100.0, 100.0, -100.0, 100.0);
}

const int n = 3600;
const GLfloat R = 35; //��Υb�| 
const GLfloat pi = 3.1415926536f;

void lineSegment (void){
    //���� 
    glBegin(GL_POLYGON);
		glColor3f(1.0,0.0,0.0); 
		for (int i = 1; i <= n; i++){
			glVertex2f(-31+R*cos(2*pi/n*i),22+R*sin(2*pi/n*i));
		}
    glEnd();
    //��� 
    glBegin(GL_POLYGON);
		glColor3f(0.0,1.0,0.0); 
		for (int i = 1; i <= n; i++){
			glVertex2f(R*cos(2*pi/n*i),45+R*sin(2*pi/n*i));
		}
	glEnd();
	//�Ŧ� 
	glBegin(GL_POLYGON);
		glColor3f(0.0,0.0,1.0);
		for (int i = 1; i <= n; i++){
			glVertex2f(31+R*cos(2*pi/n*i),22+R*sin(2*pi/n*i));
		}
    glEnd();
    //���� 
    glBegin(GL_POLYGON);
		glColor3f(1.0,1.0,0.0); 
		for (int i = 1; i <= n; i++){
			glVertex2f(18+R*cos(2*pi/n*i),-13+R*sin(2*pi/n*i));
		}
    glEnd();
    //�L�� 
    glBegin(GL_POLYGON);
		glColor3f(0.0,1.0,1.0);
		for (int i = 1; i <= n; i++){
			glVertex2f(-18+R*cos(2*pi/n*i),-13+R*sin(2*pi/n*i));
		}
    glEnd();
    //������ 
    glLineWidth(3);
	glBegin(GL_LINE_LOOP);
		glColor3f(0.0,0.0,0.0); 
		glVertex2i (-31,22);
		glVertex2i (0,45);
		glVertex2i (31,22);
		glVertex2i (18,-13);
		glVertex2i (-18,-13);
    glEnd();
    glFlush();
}

int main (int argc, char** argv){
	glutInit (&argc, argv); // Initialize GLUT.
	glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);   // Set display mode.
	glutInitWindowPosition (100,50);   // Set top-left display-window position.
	glutInitWindowSize (500, 500);// Set display-window width and height.
	glutCreateWindow ("B0729025_training2-1"); // Create display window.
	init ( );
	glutDisplayFunc (lineSegment); // Send graphics to display window.
	glutMainLoop ( );  // Display everything and wait.
}
