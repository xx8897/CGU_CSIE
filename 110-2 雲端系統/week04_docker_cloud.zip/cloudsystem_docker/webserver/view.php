<?php
ini_set('display_errors','1');
error_reporting(E_ALL);
header('refresh: 3;');

$output = "/share/".$_GET["jobId"]."/output.txt";
#echo $output;
if(file_exists($output)){
	$fp = fopen($output,"r");
	while($line=fgets($fp)){
		echo $line;
	}
	fclose($fp);
}
else{
	echo "Queuing...\n";
}
?>
