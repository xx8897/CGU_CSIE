int mult (int x, int y);
int calculate (int a, int b, int c);
