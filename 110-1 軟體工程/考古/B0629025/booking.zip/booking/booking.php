<?php include('header.php') ?>
<?php
	
	if (!empty($_GET['date'])) {
	  $date = $_GET['date'];
    $startStation = $_GET['startStation'];
    $startStationKey = getStationKey($_GET['startStation']);
    $endStation = $_GET['endStation'];
    $endStationKey = getStationKey($_GET['endStation']);
    $startTime = $_GET['startTime'];
    $endTime = $_GET['endTime'];
    $sql = "select * from train where $startStationKey > :startTime && $startStationKey < :endTime && isNorth = :isNorth && $startStationKey <> '' && $endStationKey <> ''";
    $statement = $pdo->prepare($sql);
    $statement->execute(array(
      'startTime' => $startTime,
      'endTime' => $endTime,
      'isNorth' => $startStation > $endStation ? 0 : 1
    ));
		$data = $statement->fetchAll(PDO::FETCH_ASSOC);

  }
?>

<!--新增/修改-->
<?php
if (!empty($_POST['create'])) {
	if (!empty($_POST['bookingId'])) {
		$sql = "update booking set trainNumber = :trainNumber, date = :date, startTime = :startTime, endTime = :endTime, startStation = :startStation, endStation = :endStation where bookingId = :bookingId";
    $statement = $pdo->prepare($sql);
		$statement->execute(array(
      'trainNumber' => $_POST['trainNumber'],
      'date' => $_POST['date'],
      'startTime' => $_POST['startTime'],
      'endTime' => $_POST['endTime'],
      'startStation' => $_POST['startStation'],
      'endStation' => $_POST['endStation'],
      'bookingId' => $_POST['bookingId'],
    ));
    echo ("<script>window.alert('已修改');window.location.href='booking-search.php';</script>");
  } else {
    $sql = "insert into booking(userId, trainNumber, date, startTime, endTime, startStation, endStation) values (:userId, :trainNumber, :date, :startTime, :endTime, :startStation, :endStation)";
    $statement = $pdo->prepare($sql);
    $statement->execute(array(
      'userId' => $_SESSION['userId'],
      'trainNumber' => $_POST['trainNumber'],
      'date' => $_POST['date'],
      'startTime' => $_POST['startTime'],
      'endTime' => $_POST['endTime'],
      'startStation' => $_POST['startStation'],
      'endStation' => $_POST['endStation'],
    ));
    echo ("<script>window.alert('已訂購');window.location.href='booking-search.php';</script>");
  }
}
?>



<section class="mt-5 content">
  <h1 class="font-weight-light text-center text-lg-left mb-0">訂票</h1>
  <hr class="mt-2 mb-5">
  <form method="get">
    <?php
      if (!empty($_GET['bookingId'])) {
    ?>
      <input type="hidden" name="bookingId" value="<?=$_GET['bookingId']?>">
    <?php
      }
    ?>
    <div class="row">
      <div class="col-sm-6 form-group row">
        <label class="col-sm-2 col-form-label">出發站</label>
        <div class="col-sm-10">
          <select name="startStation" class="form-control">
            <option value="1" <?=!empty($startStation) && $startStation === '1' ? 'selected' : ''?>>南港站</option>
            <option value="2" <?=!empty($startStation) && $startStation === '2' ? 'selected' : ''?>>台北站</option>
            <option value="3" <?=!empty($startStation) && $startStation === '3' ? 'selected' : ''?>>板橋站</option>
            <option value="4" <?=!empty($startStation) && $startStation === '4' ? 'selected' : ''?>>桃園站</option>
            <option value="5" <?=!empty($startStation) && $startStation === '5' ? 'selected' : ''?>>新竹站</option>
            <option value="6" <?=!empty($startStation) && $startStation === '6' ? 'selected' : ''?>>苗栗站</option>
            <option value="7" <?=!empty($startStation) && $startStation === '7' ? 'selected' : ''?>>台中站</option>
            <option value="8" <?=!empty($startStation) && $startStation === '8' ? 'selected' : ''?>>彰化站</option>
            <option value="9" <?=!empty($startStation) && $startStation === '9' ? 'selected' : ''?>>雲林站</option>
            <option value="10" <?=!empty($startStation) && $startStation === '10' ? 'selected' : ''?>>嘉義站</option>
            <option value="11" <?=!empty($startStation) && $startStation === '11' ? 'selected' : ''?>>台南站</option>
            <option value="12" <?=!empty($startStation) && $startStation === '12' ? 'selected' : ''?>>左營站</option>
          </select>
        </div>
      </div>
      <div class="col-sm-6 form-group row">
        <label class="col-sm-2 col-form-label">抵達站</label>
        <div class="col-sm-10">
          <select name="endStation" class="form-control">
            <option value="1" <?=!empty($endStation) && $endStation === '1' ? 'selected' : ''?>>南港站</option>
            <option value="2" <?=!empty($endStation) && $endStation === '2' ? 'selected' : ''?>>台北站</option>
            <option value="3" <?=!empty($endStation) && $endStation === '3' ? 'selected' : ''?>>板橋站</option>
            <option value="4" <?=!empty($endStation) && $endStation === '4' ? 'selected' : ''?>>桃園站</option>
            <option value="5" <?=!empty($endStation) && $endStation === '5' ? 'selected' : ''?>>新竹站</option>
            <option value="6" <?=!empty($endStation) && $endStation === '6' ? 'selected' : ''?>>苗栗站</option>
            <option value="7" <?=!empty($endStation) && $endStation === '7' ? 'selected' : ''?>>台中站</option>
            <option value="8" <?=!empty($endStation) && $endStation === '8' ? 'selected' : ''?>>彰化站</option>
            <option value="9" <?=!empty($endStation) && $endStation === '9' ? 'selected' : ''?>>雲林站</option>
            <option value="10" <?=!empty($endStation) && $endStation === '10' ? 'selected' : ''?>>嘉義站</option>
            <option value="11" <?=!empty($endStation) && $endStation === '11' ? 'selected' : ''?>>台南站</option>
            <option value="12" <?=!empty($endStation) && $endStation === '12' ? 'selected' : ''?>>左營站</option>
          </select>
        </div>
      </div>
    </div>
    <!--時段-->
    <div class="row">
      <div class="col-sm-6 form-group row">
        <label class="col-sm-2 col-form-label">日期</label>
        <div class="col-sm-10">
           <input name="date"  class="datepicker form-control" value="<?=empty($date) ? '' : $date?>" required/>
        </div>
      </div>
      <div class="col-sm-6 row">
        <label class="col-sm-2 col-form-label">時段</label>
        <div class="col-sm-10 row">
           <div class="col-sm-5">
	           <input name="startTime" type="time" class="form-control" value="<?=empty($startTime) ? '' : $startTime?>" required>
           </div>
          <span>至</span>
          <div class="col-sm-5">
	           <input name="endTime" type="time" class="form-control" value="<?=empty($endTime) ? '' : $endTime?>" required>
          </div>
        </div>
      </div>
    </div>
    <button type="submit" class="btn btn-primary btn-lg btn-block">查詢車次</button>
  </form>

<?php
  	if (!empty($_GET['date'])) {
?>
  <table class="table" style="margin-top: 12px">
      <thead class="thead-dark">
        <tr>
          <th scope="col">車次</th>
          <th scope="col">乘車日期</th>
          <th scope="col">出發時間</th>
          <th scope="col">抵達時間</th>
          <th scope="col">訂購</th>
        </tr>
      </thead>
      <tbody>
      <?php
        foreach ($data as $key=>$item) {
      ?>
        <tr>
          <th scope="row"><?=$item['trainNumber']?></th>
          <td><?=$date?></td>
          <td><?=$item[$startStationKey]?></td>
          <td><?=$item[$endStationKey]?></td>
          <th scope="col">
            <form id="createForm<?=$key?>"  method="post">
              <?php
                if (!empty($_GET['bookingId'])) {
              ?>
                <input type="hidden" name="bookingId" value="<?=$_GET['bookingId']?>">
              <?php
                }
              ?>
              <input type="hidden" name="create" value="1">
              <input type="hidden" name="trainId" value="<?=$item['trainId']?>">
              <input type="hidden" name="date" value="<?=$date?>">
              <input type="hidden" name="trainNumber" value="<?=$item['trainNumber']?>">
              <input type="hidden" name="startTime" value="<?=$item[$startStationKey]?>">
              <input type="hidden" name="endTime" value="<?=$item[$endStationKey]?>">
              <input type="hidden" name="startStation" value="<?=$startStation?>">
              <input type="hidden" name="endStation" value="<?=$endStation?>">
              <a href="#" onclick="document.getElementById('createForm<?=$key?>').submit();">訂購</a>
            </form>
          </th>
        </tr>
      <?php
        }
      ?>
      </tbody>
    </table>
<?php
  }
?>
</section>

