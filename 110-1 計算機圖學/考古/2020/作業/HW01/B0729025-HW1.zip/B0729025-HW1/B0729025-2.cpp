#include<stdlib.h>
#include<stdio.h>
#include<time.h>
#include<GL/glut.h>
#include<math.h>

void init (void){
	glClearColor (1.0, 1.0, 1.0, 0.0);  // Set display-window color to white.
	glMatrixMode (GL_PROJECTION);       // Set projection parameters.
	gluOrtho2D (-100.0, 100.0, -100.0, 100.0);
}

void lineSegment (void){
	glClear (GL_COLOR_BUFFER_BIT);
	/////////////////////////////GL_TRIANGLE_STRIP
	glBegin (GL_TRIANGLE_STRIP);
		glColor3f (1.0, 0.0, 0.0);
		glVertex2i (-80,0);
		glVertex2i (-40,10);
		glVertex2i (-30,0);
		glVertex2i (-20,50);
	glEnd ( );
	/////////////////////////////GL_QUAD_STRIP
		glBegin (GL_QUAD_STRIP);
		glColor3f (0.0, 1.0, 0.0);
		glVertex2i (20,0);
		glVertex2i (30,10);
		glVertex2i (40,0);
		glVertex2i (50,10);
	glEnd ( );
	/////////////////////////////GL_TRIANGLE_FAN
		glBegin (GL_TRIANGLE_FAN);
		glColor3f (0.0, 0.0, 1.0);
		glVertex2i (20,50);
		glVertex2i (60,55);
		glVertex2i (50,65);
		glVertex2i (60,75);
		glVertex2i (70,100);
	glEnd ( );
	/////////////////////////////GL_QUADS
	glBegin (GL_QUADS);
	glColor3f (1.0, 1.0, 0.0);
	glVertex2i (20,-50);
	glVertex2i (60,-50);
	glVertex2i (40,-75);
	glVertex2i (30,-75);
	glEnd();
    glFlush();
}
	
int main (int argc, char** argv){
	glutInit (&argc, argv); // Initialize GLUT.
	glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);   // Set display mode.
	glutInitWindowPosition (100,50);   // Set top-left display-window position.
	glutInitWindowSize (500, 500);// Set display-window width and height.
	glutCreateWindow ("B0729025_HW1-2"); // Create display window.
	init ( );
	glutDisplayFunc (lineSegment); // Send graphics to display window.
	glutMainLoop ( );  // Display everything and wait.
}
