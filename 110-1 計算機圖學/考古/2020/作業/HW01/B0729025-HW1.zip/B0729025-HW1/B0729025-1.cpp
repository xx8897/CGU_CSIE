#include<stdlib.h>
#include<stdio.h>
#include<time.h>
#include<GL/glut.h>
#include<math.h>
#include <time.h>

void init (void){
	glClearColor (0.1, 0.1, 0.3, 0.0);  // Set display-window color to white.
	glMatrixMode (GL_PROJECTION);       // Set projection parameters.
	gluOrtho2D (0.0, 320.0, 0.0, 200.0);
}

void lineSegment (void){
	srand(time(0));
	glClear (GL_COLOR_BUFFER_BIT);  // Clear display window.
	//��a 
	glColor3f (0.0, 0.5, 0.0);
	glBegin (GL_POLYGON);
		glVertex2i (0,0);
		glVertex2i (320,0);
		glVertex2i (320,65);
		glVertex2i (0,65);
	glEnd ( );
	//��}
	glColor3f (0.5, 0.3, 0.1);
	glBegin (GL_POLYGON);
		glVertex2i (290,50);
		glVertex2i (285,50);
		glVertex2i (285,30);
		glVertex2i (290,30);
	glEnd ( );
	glColor3f (0.0, 0.0, 0.0);
	glBegin (GL_LINE_LOOP);
		glVertex2i (290,50);
		glVertex2i (285,50);
		glVertex2i (285,30);
		glVertex2i (290,30);
	glEnd ( );
	glColor3f (0.5, 0.3, 0.1);
	glBegin (GL_POLYGON);
		glVertex2i (210,50);
		glVertex2i (215,50);
		glVertex2i (215,30);
		glVertex2i (210,30);
	glEnd ( );
	glColor3f (0.0, 0.0, 0.0);
	glBegin (GL_LINE_LOOP);
		glVertex2i (210,50);
		glVertex2i (215,50);
		glVertex2i (215,30);
		glVertex2i (210,30);
	glEnd ( );
	glColor3f (0.5, 0.3, 0.1);
	glBegin (GL_POLYGON);
		glVertex2i (310,75);
		glVertex2i (305,75);
		glVertex2i (305,50);
		glVertex2i (310,50);
	glEnd ( );
	glColor3f (0.0, 0.0, 0.0);
	glBegin (GL_LINE_LOOP);
		glVertex2i (310,75);
		glVertex2i (305,75);
		glVertex2i (305,50);
		glVertex2i (310,50);
	glEnd ( );
	//�ୱ 
	glColor3f (0.5, 0.3, 0.1);
	glBegin (GL_POLYGON);
		glVertex2i (210,50);
		glVertex2i (290,50);
		glVertex2i (310,75);
		glVertex2i (230,75);
	glEnd ( );
	glColor3f (0.0, 0.0, 0.0);
	glBegin (GL_LINE_LOOP);
		glVertex2i (210,50);
		glVertex2i (290,50);
		glVertex2i (310,75);
		glVertex2i (230,75);
	glEnd ( );
	glColor3f (0.5, 0.3, 0.1);
	glBegin (GL_POLYGON);
		glVertex2i (210,50);
		glVertex2i (290,50);
		glVertex2i (290,45);
		glVertex2i (210,45);
	glEnd ( );
	glColor3f (0.0, 0.0, 0.0);
	glBegin (GL_LINE_LOOP);
		glVertex2i (210,50);
		glVertex2i (290,50);
		glVertex2i (290,45);
		glVertex2i (210,45);
	glEnd ( );
	glColor3f (0.5, 0.3, 0.1);
	glBegin (GL_POLYGON);
		glVertex2i (290,50);
		glVertex2i (290,45);
		glVertex2i (310,70);
		glVertex2i (310,75);
	glEnd ( );
	glColor3f (0.0, 0.0, 0.0);
	glBegin (GL_LINE_LOOP);
		glVertex2i (290,50);
		glVertex2i (290,45);
		glVertex2i (310,70);
		glVertex2i (310,75);
	glEnd ( );	 
	//�� 
	glColor3f (0.3, 0.3, 0.3);
	glBegin (GL_POLYGON);
	glVertex2i (30,0);
	glVertex2i (150,0);
	glVertex2i (45,65);
	glVertex2i (23,65);
	glEnd ( );
	/////////�b�O
	//���� 
	glColor3f (5.0, 0.9, 0.0);
	glBegin (GL_POLYGON);
	glVertex2i (50,35);
	glVertex2i (170,15);
	glVertex2i (200,100);
	glVertex2i (85,120);
	glEnd ( );
	//�¦�
	glColor3f (0.0, 0.0, 0.0);
	glBegin (GL_LINE_LOOP);
	glVertex2i (50,35);
	glVertex2i (170,15);
	glVertex2i (200,100);
	glVertex2i (85,120);
	glEnd ( );
	//����T����
	glColor3f (5.0, 0.8, 0.0);
	glBegin (GL_POLYGON);
	glVertex2i (200,100);
	glVertex2i (171,17);
	glVertex2i (200,25);
	glEnd ( );
	//�k��T����
	glColor3f (5.0, 0.8, 0.0);
	glBegin (GL_POLYGON);////////////GL_POLYGON
	glVertex2i (200,100);
	glVertex2i (229,33);
	glVertex2i (200,25);
	glEnd ( );
	//�¦�u 
	glColor3f (0.0, 0.0, 0.0);
	glBegin (GL_LINE_STRIP);/////////GL_LINE_STRIP
	glVertex2i (200,100);
	glVertex2i (171,17);
	glVertex2i (200,25);
	glEnd ( ); 
	//�¦�u 
	glColor3f (0.0, 0.0, 0.0);
	glBegin (GL_LINE_LOOP);//////////GL_LINE_LOOP
	glVertex2i (200,100);
	glVertex2i (229,33);
	glVertex2i (200,25);
	glEnd ( );
	//�T����
	glColor3f (0.2, 0.4, 1.0);
	glBegin (GL_TRIANGLES);//////////GL_TRIANGLES
	glVertex2i (85,120);
	glVertex2i (90,105);
	glVertex2i (98,118);
	glEnd ( );
	glColor3f (1.0, 0.4, 0.8);
	glBegin (GL_TRIANGLES);
	glVertex2i (98,118);
	glVertex2i (103,103);
	glVertex2i (112,115);
	glEnd ( );
	glColor3f (0.2, 0.4, 1.0);
	glBegin (GL_TRIANGLES);
	glVertex2i (112,115);
	glVertex2i (117,101);
	glVertex2i (126,113);
	glEnd ( );
	glColor3f (1.0, 0.4, 0.8);
	glBegin (GL_TRIANGLES);
	glVertex2i (126,113);
	glVertex2i (131,99);
	glVertex2i (139,111);
	glEnd ( );
	glColor3f (0.2, 0.4, 1.0);
	glBegin (GL_TRIANGLES);
	glVertex2i (139,111);
	glVertex2i (143,97);
	glVertex2i (152,109);
	glEnd ( );
	glColor3f (1.0, 0.4, 0.8);
	glBegin (GL_TRIANGLES);
	glVertex2i (152,109);
	glVertex2i (156,95);
	glVertex2i (164,106);
	glEnd ( );
	glColor3f (0.2, 0.4, 1.0);
	glBegin (GL_TRIANGLES);
	glVertex2i (164,106);
	glVertex2i (168,93);
	glVertex2i (176,104);
	glEnd ( );
	glColor3f (1.0, 0.4, 0.8);
	glBegin (GL_TRIANGLES);
	glVertex2i (176,104);
	glVertex2i (180,91);
	glVertex2i (188,102);
	glEnd ( );
	glColor3f (0.2, 0.4, 1.0);
	glBegin (GL_TRIANGLES);
	glVertex2i (188,102);
	glVertex2i (190,88);
	glVertex2i (200,100);
	glEnd ( );
	//�P�P 
	glColor3f (1.0, 1.0, 0.0);
	glBegin (GL_POINTS);/////////////GL_POINTS
		for(int i=0;i<300;i++){
			int x=rand()%321+0;
			int y=rand()%161+140;
			glVertex2i (x,y);
			i++;
		}
	glEnd ( );
	//�v�l
	glColor3f (0.0, 0.0, 0.0);
	glLineWidth(5);
	glBegin (GL_LINES);////////////GL_LINES
	glVertex2i (58,35);
	glVertex2i (58,47);
	glEnd ( ); 
	glBegin (GL_LINES);
	glVertex2i (165,30);
	glVertex2i (165,18);
	glEnd ( );
	glBegin (GL_LINES);
	glVertex2i (228,43);
	glVertex2i (228,32);
	glEnd ( );
	glFlush();
}

int main (int argc, char** argv){
	glutInit (&argc, argv); // Initialize GLUT.
	glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);   // Set display mode.
	glutInitWindowPosition (100,50);   // Set top-left display-window position.
	glutInitWindowSize (800, 500);// Set display-window width and height.
	glutCreateWindow ("B0729025_HW1-1"); // Create display window.
	init ( );
	glutDisplayFunc (lineSegment); // Send graphics to display window.
	glutMainLoop ( );  // Display everything and wait.
}
