<?php include('default.php') ?>
<?php include('db.php') ?>
<?php
  if (empty($_SESSION['userId']) || !empty($_POST['logout'])) {
    session_destroy();
    echo ("<script>window.location.href='login.php';</script>");
  }
?>

<?php
	function getStation($station) {
		switch ($station) {
			case 1:
				return '南港站';
			case 2:
        return '台北站';
      case 3:
        return '板橋站';
      case 4:
        return '桃園站';
      case 5:
        return '新竹站';
      case 6:
        return '苗栗站';
      case 7:
        return '台中站';
      case 8:
        return '彰化站';
      case 9:
        return '雲林站';
      case 10:
        return '嘉義站';
      case 11:
        return '台南站';
      case 12:
        return '左營站';
		}
	}

	function getStationKey($station) {
    switch ($station) {
      case 1:
        return 'nangang';
      case 2:
        return 'taipei';
      case 3:
        return 'itabashi';
      case 4:
        return 'taoyuan';
      case 5:
        return 'hsinchu';
      case 6:
        return 'miaoli';
      case 7:
        return 'taichung';
      case 8:
        return 'changhua';
      case 9:
        return 'yunlin';
      case 10:
        return 'chiayi';
      case 11:
        return 'tainan';	
      case 12:
        return 'zuoying';
    }
  }
?>

<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
  <div class="container">
    <a class="navbar-brand" href="#">訂票系統</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link" href="booking.php">訂票</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="booking-search.php">訂票紀錄查詢</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="schedule.php">時刻表</a>
        </li>
        <li class="nav-item">
          <form id="form" method="post">
            <input type="hidden" name="logout" value="1">
            <a class="nav-link" href="#" onclick="document.getElementById('form').submit();">登出</a>
          </form>
        </li>
      </ul>
    </div>
  </div>
</nav>
