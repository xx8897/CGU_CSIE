#include <pthread.h>
#include <stdio.h>
#include <time.h>

//the shared address space
int acc;
int count=0;
int A[100],B[100];
int sum=0;
pthread_mutex_t mylock;

void *
child_thread1 (p)
	void *p;
{
	int count1=0;
	while(count1<=24)
        {
		int sum1;
sum1=multiple(count1);
	//the critical section with mutual-exclusive synchronization
	    pthread_mutex_lock (&mylock);
	    {
	 	sum+=sum1;
		count1++;
	    }
	    pthread_mutex_unlock (&mylock);
		
        }
}//child_thread

void *
child_thread2 (p)
	void *p;
{
	int count2=25;
	while(count2<=49)
        {
		int sum1;
sum1=multiple(count2);
	//the critical section with mutual-exclusive synchronization
	    pthread_mutex_lock (&mylock);
	    {
	 	sum+=sum1;
		count2++;
	    }
	    pthread_mutex_unlock (&mylock);
		
        }
}//child_thread
void *
child_thread3 (p)
	void *p;
{
	int count3=50;
	while(count3<=74)
        {
		int sum1;
		sum1=multiple(count3);
	//the critical section with mutual-exclusive synchronization
	    pthread_mutex_lock (&mylock);
	    {
	 	sum+=sum1;
		count3++;
	    }
	    pthread_mutex_unlock (&mylock);
		
        }
}//child_thread
void *
child_thread4 (p)
	void *p;
{
	int count4=75;
	while(count4<=99)
        {
		int sum1=multiple(count4);
	//the critical section with mutual-exclusive synchronization
	    pthread_mutex_lock (&mylock);
	    {
	 	sum+=sum1;
		count4++;
	    }
	    pthread_mutex_unlock (&mylock);
		
        }
}//child_thread
main ()
{
	int i;
	
	for(i=0;i<100;i++)
	{
		A[i]=100;
		B[i]=i+1;
	}
	acc = 0;
	count = 2; 
        clock_t start, finish;
        double duration;
        start = clock();
        pthread_t thread1,thread2,thread3,thread4;  
        pthread_mutex_init(&mylock,NULL);
        pthread_create(&thread1,NULL,child_thread1,NULL);
        pthread_create(&thread2,NULL,child_thread2,NULL);
        pthread_create(&thread3,NULL,child_thread3,NULL);
        pthread_create(&thread4,NULL,child_thread4,NULL);
        pthread_join(thread1,NULL);
	pthread_join(thread2,NULL);
        pthread_join(thread3,NULL);
        pthread_join(thread4,NULL);
        finish = clock();   
        duration = (double)(finish - start) / CLOCKS_PER_SEC;   
        printf( "It take %f seconds\n sum = %d\n", duration,sum );   
	return 0;
}//main ()


int multiple(int count)
{
	return A[count]*B[count];
}















