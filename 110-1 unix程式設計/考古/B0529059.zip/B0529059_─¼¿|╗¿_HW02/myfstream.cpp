#include"myfstream.h"
void myfstream::openFile( const char* filename )
{
	this->fileID = open( filename, O_RDWR|O_CREAT, S_IRWXU );
}

void myfstream::closeFile()
{
	close(this->fileID);
}

void myfstream::readFile( char* str, int strsize )
{
	for(int i=0;i<strsize;i++)
		read( this->fileID, str+i, 1 );
	*(str+strsize) = ' ';
}

void myfstream::writeFile( const char* str, int strsize )
{
	for(int i=0;i<strsize;i++)
		write( this->fileID, str+i, 1 );
}

myfstream& myfstream::operator>>( char* str )
{
	for( int n=0; *(str+n)!=' '; n++ )
		read( this->fileID, str+n, 1 );
}

myfstream& myfstream::operator<<( char* str )
{
	for( int n=0; *(str+n)!=' '; n++ )
		write( this->fileID, str+n, 1 );
}
