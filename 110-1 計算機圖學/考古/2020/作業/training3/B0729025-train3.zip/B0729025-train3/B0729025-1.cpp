#include<stdlib.h>
#include<stdio.h>
#include<time.h>
#include<GL/glut.h>
#include<math.h>
#include<iostream>

using namespace std;

void init (void){
	glClearColor (1.0, 1.0, 1.0, 0.0);  // Set display-window color to white.
	glMatrixMode (GL_PROJECTION);       // Set projection parameters.
	gluOrtho2D (0.0,600.0,0.0,600.0);
}

const int n = 3600;
const GLfloat pi = 3.1415926536f;

void lineSegment (void){
	glClear(GL_COLOR_BUFFER_BIT);
	srand(time(0));
	for(int j=0;j<20;j++){
		GLfloat R; //��Υb�| 
		R=rand()%200+1;
		int h=rand()%401+100;
		int w=rand()%401+100;
		
		if(((h-R)<100)||((h+R)>500)||((w-R)<100)||((w+R)>500)){
			j--;
			continue;
		}
		glBegin(GL_POLYGON);
		int r,g,b;
		int c=rand()%6+1;
		switch(c){
			case 1:
				r=1;
				g=0;
				b=0;
				break;
			case 2:
				r=0;
				g=1;
				b=0;
				break;
			case 3:
				r=0;
				g=0;
				b=1;
				break;
			case 4:
				r=1;
				g=1;
				b=0;
				break;
			case 5:
				r=1;
				g=0;
				b=1;
				break;
			case 6:
				r=0;
				g=1;
				b=1;
				break;
		}
		glColor3f(r,g,b);
		for (int i=1;i<=n;i++){
			glVertex2f(w+R*cos(2*pi/n*i),h+R*sin(2*pi/n*i));
		}
		glEnd();
    }
    glColor3f (0.0, 0.0, 1.0);
    glBegin (GL_LINE_LOOP);
		glVertex2i (100,100);
		glVertex2i (500,100);
		glVertex2i (500,500);
		glVertex2i (100,500);
	glEnd ( );
    glFlush();
}

int main (int argc, char** argv){
	glutInit (&argc, argv); // Initialize GLUT.
	glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);   // Set display mode.
	glutInitWindowPosition (100,50);   // Set top-left display-window position.
	glutInitWindowSize (500, 500);// Set display-window width and height.
	glutCreateWindow ("B0729025_training3-1"); // Create display window.
	init ( );
	glutDisplayFunc (lineSegment); // Send graphics to display window.
	glutMainLoop ( );  // Display everything and wait.
}
