import matplotlib.pyplot as plt

listx = [1,5,7,9,13,16]
listy = [15,50,80,40,70,50]
plt.plot(listx, listy, color ="red", linestyle=':', linewidth='2', label='Hello world')
plt.legend()

