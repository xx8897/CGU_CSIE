#include<stdlib.h>
#include<stdio.h>
#include<time.h>
#include<GL/glut.h>
#include<math.h>

void init (void){
	glClearColor (1.0, 1.0, 1.0, 0.0);  // Set display-window color to white.
	glMatrixMode (GL_PROJECTION);       // Set projection parameters.
	gluOrtho2D (-100.0, 100.0, -100.0, 100.0);
}


void lineSegment (void){
	glClear (GL_COLOR_BUFFER_BIT);  // Clear display window.
	//�~���T���� 
	glColor3f (1.0, 1.0, 1.0);
		glBegin (GL_POLYGON);
		glVertex2i (-80,-75);
		glVertex2i (80,-75);
		glVertex2i (0,65);
	glEnd ( );
	//�~���T���ζ½u 
	glLineWidth(3);
	glColor3f (0.0, 0.0, 0.0);
		glBegin (GL_LINE_STRIP);
		glVertex2i (-80,-75);
		glVertex2i (80,-75);
		glVertex2i (0,65);
		glVertex2i (-80,-75);
	glEnd ( );
	//�̭�����T���� 
	glColor3f (1.0, 1.0, 0.0);
		glBegin (GL_POLYGON);
		glVertex2i (-70,-70);
		glVertex2i (70,-70);
		glVertex2i (0,55);
	glEnd ( );
	//�̭��T���ζ½u 
	glLineWidth(8);
	glColor3f (0.0, 0.0, 0.0);
		glBegin (GL_LINE_STRIP);
		glVertex2i (-70,-70);
		glVertex2i (70,-70);
		glVertex2i (0,55);
		glVertex2i (-70,-70);
	glEnd ( );
	//�{�q1
	glColor3f (0.0, 0.0, 0.0);
		glBegin (GL_POLYGON);
		glVertex2i (-5,25);
		glVertex2i (8,25);
		glVertex2i (-10,-22);
	glEnd ( );
	//�{�q2 
	glColor3f (0.0, 0.0, 0.0);
		glBegin (GL_POLYGON);
		glVertex2i (-10,-22);
		glVertex2i (-9,-17);
		glVertex2i (10,-5);
		glVertex2i (10,-10);
	glEnd ( );
	//�{�q3
	glColor3f (0.0, 0.0, 0.0);
		glBegin (GL_POLYGON);
		glVertex2i (10,-8);
		glVertex2i (0,-55);
		glVertex2i (0,-13);
	glEnd ( );
	//�{�q4
	glColor3f (0.0, 0.0, 0.0);
		glBegin (GL_POLYGON);
		glVertex2i (1,-55);
		glVertex2i (8,-40);
		glVertex2i (-5,-40);
	glEnd ( );
	
    glFlush();
}

int main (int argc, char** argv){
	glutInit (&argc, argv); // Initialize GLUT.
	glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);   // Set display mode.
	glutInitWindowPosition (100,50);   // Set top-left display-window position.
	glutInitWindowSize (500, 500);// Set display-window width and height.
	glutCreateWindow ("B0729025_1"); // Create display window.
	init ( );
	glutDisplayFunc (lineSegment); // Send graphics to display window.
	glutMainLoop ( );  // Display everything and wait.
}
